import React, { useEffect, useState } from "react";

import { View, Text, StyleSheet, Pressable } from "react-native";

import type { ViewStyle, StyleProp } from "react-native";

import Svg, { Circle, Path } from "react-native-svg";

import DrawingStroke from "../../components/DrawingStroke";

import { useTracingProgress } from "../hooks/useTracingProgress";

import type { TracingGuide } from "../types/tracing.types";

import PandaMover, { PandaAnimationPhase } from "./PandaMover";
import PandaJourneyAnimation from "./PandaJourneyAnimation";

interface TracingCanvasProps {
  guide: TracingGuide;
  width?: number;
  height?: number;
  style?: StyleProp<ViewStyle>;
  guideColor?: string;
  strokeColor?: string;
  strokeWidth?: number;
  onComplete?: () => void;
  resetKey: number;
}

export const TracingCanvas: React.FC<TracingCanvasProps> = ({
  guide,
  width = 320,
  height = 420,
  style,
  guideColor = "#D9CBEF",
  strokeColor = "#9B7AEA",
  strokeWidth = 10,
  onComplete,
  resetKey,
}) => {
  const {
    panResponder,
    currentStroke,
    strokes,
    isDrawing,
    progress,
    isCompleted,
    completedSegments,
    resetTracing,
  } = useTracingProgress(guide, {
    onComplete,
  });
  const [phase, setPhase] = useState<PandaAnimationPhase>("WAITING");
  const guidePoints = guide.points;

  const guidePath = guidePoints
    .map((point, index) => {
      return `${index === 0 ? "M" : "L"} ${point.x} ${point.y}`;
    })
    .join(" ");

  // 시작점과 도착점
  const firstPoint = guidePoints[0];
  const endPoint = guidePoints[guidePoints.length - 1];

  // 현재 손가락이 그리는 선
  // 손가락을 떼면 마지막으로 완성한 스트로크를 사용
  const activeStroke =
    currentStroke.length > 0
      ? currentStroke
      : (strokes[strokes.length - 1] ?? []);

  // 팬더곰이 따라갈 현재 위치
  const activePoint = activeStroke[activeStroke.length - 1];

  const pandaPositionX = activePoint?.x ?? firstPoint?.x ?? 0;

  const pandaPositionY = activePoint?.y ?? firstPoint?.y ?? height / 2;

  useEffect(() => {
    if (resetKey > 0) {
      resetTracing();
    }
  }, [resetKey, resetTracing]);
  return (
    <View style={[styles.container, style]}>
      {/* 진행률 */}
      <View style={styles.progressContainer}>
        <Text style={styles.progressLabel}>
          {isCompleted ? "참 잘했어요! 🎉" : "길을 따라가 볼까요?"}
        </Text>

        <View style={styles.progressTrack}>
          <View
            style={[
              styles.progressFill,
              {
                width: `${Math.round(progress * 100)}%`,
              },
            ]}
          />
        </View>

        <Text style={styles.progressText}>{Math.round(progress * 100)}%</Text>
      </View>

      {/* 그리기 영역 */}
      <View
        style={[styles.canvas, { width, height }]}
        {...panResponder.panHandlers}
      >
        <Svg width="100%" height="100%" style={StyleSheet.absoluteFill}>
          {/* 1. 원래 안내선 */}
          <Path
            d={guidePath}
            fill="none"
            stroke={guideColor}
            strokeWidth={4}
            strokeDasharray="0.1 9"
            strokeLinecap="round"
          />

          {/* 2. 완성된 구간 */}
          {completedSegments.map((completed, index) => {
            if (!completed) return null;

            const start = guidePoints[index];
            const end = guidePoints[index + 1];

            if (!start || !end) return null;

            return (
              <Path
                key={`completed-${index}`}
                d={`M ${start.x} ${start.y} L ${end.x} ${end.y}`}
                fill="none"
                stroke={strokeColor}
                strokeWidth={strokeWidth}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            );
          })}

          {/* 3. 현재 손가락을 따라가는 임시 선 */}
          {currentStroke.length > 0 && (
            <DrawingStroke
              points={currentStroke}
              color={strokeColor}
              strokeWidth={strokeWidth}
              opacity={0.65}
            />
          )}

          {/* 4. 시작점 */}
          {firstPoint && (
            <Circle
              cx={firstPoint.x}
              cy={firstPoint.y}
              r={7}
              fill={strokeColor}
            />
          )}

          {/* 5. 도착점 */}
          {endPoint && (
            <Circle cx={endPoint.x} cy={endPoint.y} r={7} fill="#F7C978" />
          )}
        </Svg>
        <PandaJourneyAnimation
          source={require("../../../../assets/images/baby-panda.png")}
          startPoint={firstPoint}
          endPoint={endPoint}
          isTracing={isDrawing}
          isTraceCompleted={isCompleted}
          width={width}
          height={height}
          pandaWidth={112}
          pandaHeight={140}
        />
      </View>

      {/* 다시 그리기 */}
      <Pressable style={styles.resetButton} onPress={resetTracing}>
        <Text style={styles.resetButtonText}>다시 그리기 ↻</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    gap: 16,
  },

  progressContainer: {
    width: "100%",
    gap: 8,
  },

  progressLabel: {
    fontSize: 17,
    fontWeight: "700",
    color: "#655B75",
    textAlign: "center",
  },

  progressTrack: {
    height: 12,
    borderRadius: 20,
    backgroundColor: "#EDE6F5",
    overflow: "hidden",
  },

  progressFill: {
    height: "100%",
    borderRadius: 20,
    backgroundColor: "#A78BFA",
  },

  progressText: {
    fontSize: 13,
    fontWeight: "600",
    color: "#8B7BA6",
    textAlign: "right",
  },

  canvas: {
    position: "relative",
    overflow: "hidden",
    backgroundColor: "#FFFFFF",
    borderRadius: 24,
    borderWidth: 1,
    borderColor: "#F0EAF7",
  },

  resetButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    backgroundColor: "#F0EAF7",
    borderRadius: 20,
  },

  resetButtonText: {
    fontSize: 14,
    fontWeight: "700",
    color: "#8067A5",
  },
});
